import 'package:flutter/material.dart';
import 'package:tugas1/calcu.dart';


class nama extends StatelessWidget {
  const nama({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Team Profile"),
      ),
      body: const Center(
        child: Text(
          "Halo!! Kelompok terkeren:\n"
              "1. Achmad Ikbal Rizkytama (124200019)\n"
              "2. Aloisius Fidelis B.S (124200021)\n"
              "3. Muhammad Arighi (124200071)",
          style: TextStyle(
            fontSize: 25,
          ),
        ),
      ),
    floatingActionButton: FloatingActionButton(
    onPressed: () {
    Navigator.of(context).push(
    MaterialPageRoute(builder: (context) {
    return const calcu();
    }),
    );
    },
    child: const Icon(Icons.arrow_right_alt),
    ),);
  }
}